package com.osamaalmaliki.daftar;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.widget.Toast;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.os.Build;
import android.util.Base64;
import java.io.OutputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingFileName = "export.txt";
    private String pendingMime = "text/plain";
    private String pendingContent = "";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(13, 38, 70));
        getWindow().setNavigationBarColor(Color.rgb(13, 38, 70));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(245,248,252));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private class AndroidBridge {
        @JavascriptInterface public void printPage(String title) {
            runOnUiThread(() -> {
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(
                        (title == null || title.trim().isEmpty()) ? "تقرير الإيرادات والمصروفات" : title);
                    pm.print("دفتر الإيرادات والمصروفات", adapter,
                        new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .setResolution(new android.print.PrintAttributes.Resolution("pdf", "PDF", 300, 300))
                            .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                            .build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "تعذرت الطباعة: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void saveTextFile(String name, String content, String mime) {
            pendingFileName = (name == null || name.trim().isEmpty()) ? "backup.json" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
            pendingContent = content == null ? "" : content;
            pendingMime = (mime == null || mime.trim().isEmpty()) ? "application/octet-stream" : mime;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingMime);
                intent.putExtra(Intent.EXTRA_TITLE, pendingFileName);
                try { startActivityForResult(intent, 4201); }
                catch (Exception e) { Toast.makeText(MainActivity.this, "تعذر فتح حفظ الملف", Toast.LENGTH_LONG).show(); }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 4201 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IOException("تعذر فتح الملف");
                out.write(pendingContent.getBytes(StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "تم حفظ الملف بنجاح", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "فشل حفظ الملف: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
