دفتر الإيرادات والمصروفات - مشروع Android
تصميم osama almaliki

مهم:
- هذه حزمة مصدر Android وليست APK جاهزًا للتثبيت.
- تحتاج Android Studio وAndroid SDK لبناء APK.
- افتح مجلد DaftarAndroid في Android Studio ثم اختر Build > Build APK(s).
- ملف الواجهة المحلي موجود في app/src/main/assets/index.html.
- عند تحديث البرنامج، يجب تعديل ملف HTML المشترك ثم إعادة بناء نسخة Windows وAndroid من نفس المصدر.
- البيانات المخزنة في WebView محلية على الهاتف وليست تلقائيًا نفس بيانات Windows.
- النسخ الاحتياطي إلى Google Drive يحتاج الإنترنت عند الضغط على زر الرفع.
- اختبر النسخة على جهازك قبل إدخال بيانات محاسبية مهمة، واحتفظ بنسخة JSON احتياطية.
